import java.util.Scanner;

public class Calculadora {

    public static void main(String[] args) {
        
        try (Scanner scanner = new Scanner(System.in)) {
            // aqui vai a opções para as variáveis, professor :)
            System.out.println("Escolha uma operação:");
            System.out.println("1 - Calcular Valor Futuro (M)");
            System.out.println("2 - Calcular Valor Presente (P)");
            int opcao = scanner.nextInt();
            
            switch (opcao) {
                case 1 ->                     {
                        //  Valor Futuro (M)
                        System.out.print("Digite o valor presente (P): ");
                        double P = scanner.nextDouble();
                        System.out.print("Digite a taxa de juros anual (%): ");
                        double i = scanner.nextDouble() / 100; // Converte para decimal
                        System.out.print("Digite o tempo em anos (t): ");
                        int t = scanner.nextInt();
                        // Fórmula de Valor Futuro
                        double M = P * Math.pow(1 + i, t);
                        System.out.printf("O valor futuro (M) após %d anos é: $ %.2f%n", t, M);
                    }
                case 2 ->                     {
                        // Calcular Valor Presente (P)
                        System.out.print("Digite o montante futuro (M): ");
                        double M = scanner.nextDouble();
                        System.out.print("Digite a taxa de juros anual (%): ");
                        double i = scanner.nextDouble() / 100; // Converte para decimal
                        System.out.print("Digite o tempo em anos (t): ");
                        int t = scanner.nextInt();
                        // Fórmula de Valor Presente
                        double P = M / Math.pow(1 + i, t);
                        System.out.printf("O valor presente (P) necessário para alcançar $ %.2f após %d anos é: $ %.2f%n", M, t, P);
                    }
                default -> System.out.println("Opção inválida.");
            }
        }
    }
}
